import jdk.internal.util.xml.impl.Input

class multipleOperations {

  def stringInterpol(newList:List[Int]) {
      for (indexValue <- 0 until newList.size) {
        println(s"$indexValue = ${newList(indexValue)}")
      }

    }

  def maxElement(newList: List[Int]) {
      var maxelement = newList(0)
      for (i <- newList) {
        if (maxelement < i) {
          maxelement = i
        }
      }
      println("Maximum Element = " + maxelement)
    }




  def fibonacci(n: Int) :Int =
  {
    if(n<=1){
      return n}
    return(fibonacci(n-1) + fibonacci(n-2))

  }


def factorial(input:Int): Int =
  if (input == 0) {
    return 1
  }
  else{
    return input * factorial(input-1)}



def sumOfproduct(add:Int):Int={
  if(add==0){
    return 0}
  else{
    return (add % 10) + sumOfproduct(add / 10)}
  }
}

object multiOperations{
  def main(args: Array[String]) {
     val mulop = new multipleOperations
    val val1 = 2
    val val2 = 3
    val val3 = 4
    val val4 = 7
    mulop.stringInterpol (List (val1,val2,val3,val4))
    mulop.maxElement((List(val1,val2,val3,val4)))
    val fibValue = 9
    println ("Fibonacci = " + mulop.fibonacci (fibValue))

    val factValue = 5
    var fact = mulop.factorial (factValue)
    var sum = println("SumOpProduct = " + mulop.sumOfproduct(fact))
  }
}